const languages = ["en", "nl", "it", "el", "hu"];
module.exports = {
  languages
};
