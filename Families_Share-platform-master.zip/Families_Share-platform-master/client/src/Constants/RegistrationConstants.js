const registrationConstants = {
  SIGNUP_REQUEST: "USERS_SIGNUP_REQUEST",
  SIGNUP_SUCCESS: "USERS_SIGNUP_SUCCESS",
  SIGNUP_FAILURE: "USERS_SIGNUP_FAILURE"
};

export default registrationConstants;
