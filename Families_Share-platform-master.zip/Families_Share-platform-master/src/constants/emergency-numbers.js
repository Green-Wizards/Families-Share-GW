const Italy = [
  {
    service: 'Ambulance/first aid',
    number: '118'
  },
  {
    service: 'Police',
    number: '113'
  },
  {
    service: 'Fire department',
    number: '115'
  },
  {
    service: 'Unique number of emergency',
    number: '112'
  }
]

const Belgium = [
  {
    service: 'Red cross',
    number: '105'
  },
  {
    service: 'Police',
    number: '101'
  },
  {
    service: 'Fire department',
    number: '100'
  },
  {
    service: 'Unique number of emergency',
    number: '112'
  }
]

const Greece = [
  {
    service: 'Ambulance/first aid',
    number: '166'
  },
  {
    service: 'Police',
    number: '100'
  },
  {
    service: 'Fire department',
    number: '199'
  },
  {
    service: 'Unique number of emergency',
    number: '112'
  }
]

const Hungary = [
  {
    service: 'Ambulance/first aid',
    number: '104'
  },
  {
    service: 'Police',
    number: '107'
  },
  {
    service: 'Fire department',
    number: '105'
  },
  {
    service: 'Unique number of emergency',
    number: '112'
  }
]

module.exports = {
  Italy,
  Belgium,
  Greece,
  Hungary
}
