const Italy = [
  {
    service: "ambulance",
    number: "118"
  },
  {
    service: "police",
    number: "113"
  },
  {
    service: "fire",
    number: "115"
  },
  {
    service: "general",
    number: "112"
  }
];

const Belgium = [
  {
    service: "ambulance",
    number: "105"
  },
  {
    service: "police",
    number: "101"
  },
  {
    service: "fire",
    number: "100"
  },
  {
    service: "general",
    number: "112"
  }
];

const Greece = [
  {
    service: "ambulance",
    number: "166"
  },
  {
    service: "police",
    number: "100"
  },
  {
    service: "fire",
    number: "199"
  },
  {
    service: "general",
    number: "112"
  }
];

const Hungary = [
  {
    service: "ambulance",
    number: "104"
  },
  {
    service: "police",
    number: "107"
  },
  {
    service: "fire",
    number: "105"
  },
  {
    service: "general",
    number: "112"
  }
];

module.exports = {
  Italy,
  Belgium,
  Greece,
  Hungary
};
