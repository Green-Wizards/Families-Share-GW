const languageConstants = {
  UPDATE_REQUEST: "UPDATE_LANGUAGE_REQUEST"
};

export default languageConstants;
